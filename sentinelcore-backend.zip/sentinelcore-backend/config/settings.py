"""
SentinelCore Backend - Configurações Centrais
"""

from functools import lru_cache
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- App ---
    app_name: str = "SentinelCore"
    debug: bool = False
    secret_key: str = "TROQUE-POR-UMA-CHAVE-SECRETA-FORTE-EM-PRODUCAO"

    # --- Banco de dados ---
    database_url: str = "postgresql+asyncpg://sentinel:sentinel@localhost:5432/sentinelcore"
    redis_url: str = "redis://localhost:6379/0"

    # --- IA: Claude (Anthropic) ---
    anthropic_api_key: Optional[str] = None
    claude_model: str = "claude-sonnet-4-20250514"

    # --- IA: Ollama (local) ---
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2"          # modelo base
    ollama_rag_model: str = "llama3.2"      # modelo para RAG
    rag_enabled: bool = True
    rag_collection: str = "sentinel_knowledge"
    chromadb_path: str = "./data/chromadb"  # base vetorial local

    # --- Notificações ---
    # Email
    smtp_host: Optional[str] = None
    smtp_port: int = 587
    smtp_user: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from: str = "alertas@sentinelcore.com"

    # WhatsApp (Evolution API)
    evolution_api_url: Optional[str] = None
    evolution_api_key: Optional[str] = None
    evolution_instance: Optional[str] = None

    # Slack
    slack_webhook_url: Optional[str] = None

    # Teams
    teams_webhook_url: Optional[str] = None

    # --- Grafana ---
    grafana_url: str = "http://localhost:3000"
    grafana_api_key: Optional[str] = None

    # --- n8n ---
    n8n_webhook_base: Optional[str] = None   # ex: http://localhost:5678/webhook

    # --- Segurança ---
    token_expire_hours: int = 24 * 30       # tokens de agente duram 30 dias
    rate_limit_per_minute: int = 120

    # --- CORS ---
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:5173"]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
